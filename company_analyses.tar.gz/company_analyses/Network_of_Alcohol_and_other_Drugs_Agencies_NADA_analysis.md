# Network of Alcohol and other Drugs Agencies NADA - Skills Analysis Report

## Analysis Metadata
- **Analysis Date:** 2025-11-08 10:42:07
- **Source File:** `Network_of_Alcohol_and_other_Drugs_Agencies_NADA_skills_analysis_20251108_104207.json`
- **User:** kritik@gmail.com

## Job Description

Data Analyst Network of Alcohol and other Drugs Agencies (NADA) Job Summary Network of Alcohol and other Drugs Agencies (NADA) FTE $94,919 - $103,184 per annum + salary packaging Applications close: Job posted on: 21st Jul 2025 Sydney > Woolloomooloo Part Time , Contract Information Technology & Digital Not For Profit (NFP) Job description Located in Sydney, NSW Part time – 22.8 per week (hours can be worked flexibly Monday through Friday) Fixed term contract for 52 weeks (1 year) for a parental leave replacement Salary range from FTE $94,919– $103,184 pro rata (depending on experience) + superannuation contribution + eligibility for salary packaging The Network of Alcohol and other Drugs Agencies (NADA) is the peak organisation for non-government alcohol and other drugs services in NSW. We advocate for, strengthen and support the sector. As a member driven peak body, NADA’s decisions and actions are informed by the experiences, knowledge and concerns of its membership. This exciting position will play a key role in supporting data management practices for the non-government alcohol and other drugs (AOD) sector in line with NADA’s strategic direction and the support of its member organisations. The focus of this role will be to support the non-government AOD sector in NSW in relation to clinical data management via NADAbase . If you have demonstrated experience in data management that could be applied in the AOD sector, have a good understanding of the use, analysis and reporting of client data, and have strong analytical skills then we would like to hear from you. The successful candidate for this position will have highly organised administrative skills, possess strong written and verbal communication skills, and have the ability to engage with a diverse range of stakeholders. NADA aims to provide a safe and supportive work environment in which our people can enjoy challenging and rewarding careers. We offer our staff many benefits such as annual leave loading, salary packaging benefits available to not-for-profit employees, health and wellbeing activities and opportunities for regular professional development. NADA strongly encourages applications from diverse community groups including Aboriginal and Torres Strait Islander people, people who identify as gender and sexuality diverse, people with a disability and people from culturally and linguistically diverse backgrounds. KEY RESPONSIBILITIES Supporting data management for non-government alcohol and other drug services Liaising with reporting agencies, including requests to resolve data quality issues and missing data Manage ad hoc data and reporting requests from staff, members and stakeholders, where appropriate Support the creation of a plan to improve data quality and outcomes to support evaluation Provide advice and data in line with NADA documentation, ethical and research conduct guidelines and requirements ESSENTIAL AND DESIRABLE SKILLS AND EXPERIENCE Essential: Tertiary qualifications and/or professional experience in Data Science, Information Systems, Computer Science, or a related field Advanced SQL skills (complex joins, subqueries, stored procedures) for querying and analysing data across multiple systems Hands-on experience with relational databases (e.g. SQL Server) and understanding of data structures and schemas Proficiency with reporting and BI tools (e.g. Power BI, Tableau) Familiarity with data governance frameworks and best practices Strong data analysis skills, with the ability to interpret, visualise, and communicate insights clearly Strong organisational and project management skills, with the ability to manage competing priorities and meet deadlines Effective communicator with the ability to engage technical and non-technical stakeholders and work independently or in a cross-functional team Desirable: Master’s degree or Graduate Diploma in relevant field Knowledge of alcohol and other drugs, mental health or related dataset collections and/or service delivery and/or data capability Experience in cloud-based data environments (e.g. Azure) Experience in maintaining data integrity, security, and compliance with privacy standard SELECTION CRITERIA In your cover letter, please confirm that you meet the essential skills and experience, and respond to the following questions: Describe your experience with health/community services data systems and understanding of the role of data governance. Provide examples of your organisational and communication skills and experience, including how you have managed competing priorities and engaged with both technical and non-technical stakeholders within internal and external settings. Note: During the interview, you may be asked to demonstrate your SQL skills (e.g., joins, subqueries, stored procedures) and experience with relational databases (e.g., SQL Server). The Position Description can be downloaded here . A Guide to Applying for NADA Positions can be downloaded here . Contact Dr Mei Lin Lee ( [email protected] using the subject line: Data Analyst enquiry via EthicalJobs ) or 02 8113 1319 for more information. A position description is attached. Supporting Materials Attachment icon NADA Position Description_Data Analyst_Final.pdf How to apply This job ad has now expired, and applications are no longer being accepted. Job Summary Network of Alcohol and other Drugs Agencies (NADA) FTE $94,919 - $103,184 per annum + salary packaging Applications close: Job posted on: 21st Jul 2025 Sydney > Woolloomooloo Part Time , Contract Information Technology & Digital Not For Profit (NFP) More from this Employer

---

## Skills Comparison
### Technical Skills
- **CV Skills:** 30
- **JD Requirements:** 12
- **Matched:** 3
- **Match Rate:** 25.0%
- **Matched Skills:** Power BI, SQL, Tableau
- **Missing Skills:** Azure, Data Analysis, Data Governance, Data Integrity, Data Management, Data Structures, Data Visualization, Reporting, SQL Server

### Soft Skills
- **CV Skills:** 6
- **JD Requirements:** 9
- **Matched:** 4
- **Match Rate:** 44.4%
- **Matched Skills:** Analytical Thinking, Collaboration, Communication, Problem-solving
- **Missing Skills:** Independent Work, Organization, Project Management, Stakeholder Engagement, Time Management

### Domain Keywords
- **CV Keywords:** 13
- **JD Keywords:** 8
- **Matched:** 0
- **Match Rate:** 0.0%
- **Missing Keywords:** Alcohol and Other Drugs (AOD), Clinical Data Management, Data Quality, Data Reporting, Ethical and Research Conduct, Evaluation, Health/Community Services, Not For Profit (NFP)

## CV Skills Details
### Technical Skills (30):
A/B Testing, AWS, Computer Vision, Data Warehousing, Deep Learning, Docker, ETL Pipelines, Flutter/Dart, Git/GitHub, Jupyter, Matplotlib, MySQL, NLP, Optimization, Plotly, PostgreSQL, Power BI, Predictive Modeling, Python, PyTorch, REST APIs, scikit-learn, Seaborn, Snowflake, SQL, Statistical Analysis, Tableau, TensorFlow, Time Series, VS Code

### Soft Skills (6):
Analytical Thinking, Collaboration, Communication, Innovation, Problem-solving, Results-driven

### Domain Keywords (13):
AI, ATS Optimization, Business Intelligence, Cardiovascular Risk Prediction, Construction, Corrosion Detection, Data Engineering, Data-driven Solutions, Edge AI, Forecasting, Multi-LLM Orchestration, Property Tech, Real-time Processing

## Job Description Requirements
### Required Technical Skills (12):
Azure, Data Analysis, Data Governance, Data Integrity, Data Management, Data Structures, Data Visualization, Power BI, Reporting, SQL, SQL Server, Tableau

### Required Soft Skills (9):
Analytical Thinking, Collaboration, Communication, Independent Work, Organization, Problem-solving, Project Management, Stakeholder Engagement, Time Management

### Required Domain Keywords (8):
Alcohol and Other Drugs (AOD), Clinical Data Management, Data Quality, Data Reporting, Ethical and Research Conduct, Evaluation, Health/Community Services, Not For Profit (NFP)

## CV Information
- **CV Filename:** latest_cv.pdf

## Analysis Details
- **Model Used:** unknown

---
*Generated from: /app/user/kritik@gmail.com/cv-analysis/applied_companies/Network_of_Alcohol_and_other_Drugs_Agencies_NADA/Network_of_Alcohol_and_other_Drugs_Agencies_NADA_skills_analysis_20251108_104207.json*