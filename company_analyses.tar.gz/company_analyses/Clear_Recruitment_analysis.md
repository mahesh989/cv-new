# Clear Recruitment - Skills Analysis Report

## Analysis Metadata
- **Analysis Date:** 2025-11-10 06:46:44
- **Source File:** `Clear_Recruitment_skills_analysis_20251110_064644.json`
- **User:** kritik@gmail.com

## Job Description

Visualisation Specialist - Supply Chain Data Reporting & Analytics  
Clear Recruitment  
–  
Sydney NSW  
Transform complex data into decisions that move a national supply chain. Join an enterprise-scale transformation where data drives every strategic move. You’ll take end-to-end ownership of visualisation delivery - from shaping the story to influencing senior executives - within one of Australia’s most dynamic data ecosystems. The Opportunity This is a role for a creative data storyteller who thrives at the intersection of analytics, technology and strategy. You’ll design interactive dashboards, data models, and insights that inform critical decisions - improving cost efficiency, resilience, and performance across a multi-billion-dollar supply chain network. What You’ll Do Design & Build: Develop best-in-class, interactive dashboards that turn complex datasets into clear business intelligence. Shape Insights: Use Databricks SQL and modern BI tools ( Power BI , Tableau, Looker, Qlik) to uncover trends, anomalies, and opportunities. Collaborate & Influence: Partner with data engineers, analysts, and senior executives to translate business questions into visual stories that drive action. Drive Improvement: Deliver insights that directly optimise logistics efficiency, supplier performance, and operational cost. What You’ll Bring 3–5+ years designing and deploying enterprise-level dashboards in Power BI , Tableau, or similar tools. Advanced SQL capability with strong Databricks or comparable cloud data platform experience. Experience translating and visualising data within the Supply Chain / Procurement domain Confident communicator - able to bridge technical and business audiences through clear, compelling narratives. Proactive, detail-driven mindset; comfortable working autonomously within a high-impact environment. Degree in Computer Science, Data Science, Engineering, or related field. Bonus: Familiarity with Python for data transformation or scripting. What’s In It For You Shape decision-making across a national supply chain - your dashboards will directly inform strategic planning at the highest level. Join a modern data ecosystem powered by Databricks and leading BI tools. Work alongside a passionate, cross-functional analytics team that values experimentation and innovation. Ongoing learning and development, with opportunities for certification and progression to Lead or Manager roles. Flexible hybrid working – designed around outcomes, not office hours. Why You’ll Want This Role This isn’t about producing reports - it’s about building stories that change how a business operates. You’ll be the person who helps senior leaders see the invisible, connect the dots, and act with confidence.

---

## Skills Comparison
### Technical Skills
- **CV Skills:** 36
- **JD Requirements:** 7
- **Matched:** 4
- **Match Rate:** 57.1%
- **Matched Skills:** Power BI, Python, SQL, Tableau
- **Missing Skills:** Databricks, Looker, Qlik

### Soft Skills
- **CV Skills:** 6
- **JD Requirements:** 6
- **Matched:** 4
- **Match Rate:** 66.7%
- **Matched Skills:** Analytical Thinking, Collaboration, Communication, Problem-solving
- **Missing Skills:** Creativity, Proactive

### Domain Keywords
- **CV Keywords:** 12
- **JD Keywords:** 7
- **Matched:** 0
- **Match Rate:** 0.0%
- **Missing Keywords:** Business Intelligence, Data Analytics, Data Reporting, Logistics Efficiency, Procurement, Strategic Planning, Supply Chain

## CV Skills Details
### Technical Skills (36):
A/B Testing, AI, AWS, Cloud Computing, Computer Vision, Data Engineering, Data Warehousing, Deep Learning, Docker, ETL Pipelines, Flutter/Dart, Git/GitHub, Jupyter, Machine Learning, Matplotlib, MySQL, NLP, NumPy, Optimization, Pandas, Plotly, PostgreSQL, Power BI, Predictive Modeling, Python, PyTorch, REST APIs, scikit-learn, Seaborn, Snowflake, SQL, Statistical Analysis, Tableau, TensorFlow, Time Series, VS Code

### Soft Skills (6):
Analytical Thinking, Collaboration, Communication, Problem-solving, Results-driven, Teamwork

### Domain Keywords (12):
AI Sectors, Business Intelligence Dashboards, Cardiovascular Risk Prediction, Construction, Customer Support, Data-informed Business Decisions, Edge Deployment, Forecasting Improvement, Multi-LLM Orchestration, Property Tech, Real-time ATS Optimization, Stakeholder Reporting

## Job Description Requirements
### Required Technical Skills (7):
Databricks, Looker, Power BI, Python, Qlik, SQL, Tableau

### Required Soft Skills (6):
Analytical Thinking, Collaboration, Communication, Creativity, Proactive, Problem-solving

### Required Domain Keywords (7):
Business Intelligence, Data Analytics, Data Reporting, Logistics Efficiency, Procurement, Strategic Planning, Supply Chain

## CV Information
- **CV Filename:** latest_cv.pdf

## Analysis Details
- **Model Used:** unknown

---
*Generated from: /app/user/kritik@gmail.com/cv-analysis/applied_companies/Clear_Recruitment/Clear_Recruitment_skills_analysis_20251110_064644.json*