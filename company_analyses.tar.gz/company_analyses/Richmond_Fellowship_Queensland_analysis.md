# Richmond Fellowship Queensland - Skills Analysis Report

## Analysis Metadata
- **Analysis Date:** 2025-10-31 02:01:49
- **Source File:** `Richmond_Fellowship_Queensland_skills_analysis_20251031_020149.json`
- **User:** shiva@gmail.com

## Job Description

Senior Data Analyst Richmond Fellowship Queensland Job Summary Richmond Fellowship Queensland Applications close: Job posted on: 8th Oct 2025 Brisbane & Gold Coast > Brisbane Full Time Administration , Information Technology & Digital , Project Management Not For Profit (NFP) Job description Permanent Full-time Brisbane Your next role! Are you an experienced Data Analyst looking for your next role? RFQ are in search of a Senior Data Analyst to play a key role in uplifting our data capability, inform strategic decisions, and foster a culture of empowerment, compassion, and lifelong learning. You’ll collaborate across corporate business units and Operational business areas delivering high-quality data solutions that support organisational goals and uphold professional standards. You will be joining a supportive and forward-thinking team that shares your passion for innovation and problem-solving. Your week may look like: Collaborating with key stakeholders to assess business requirements, and design and develop technical solutions to ensure data integrity and accuracy of reporting. Designing and developing reports and dashboards that uplift the organisation’s data capability to provide measures, metrics and analytical data to inform operational and strategic decision making. Participating in strategic analysis and critically evaluating organisational information and business processes, identifying areas for enhancing data management capabilities. Leading projects and where necessary provide analytical support to other projects such as process mapping of solutions and the provision of key data. You will need: Relevant formal qualifications and/or experience as a data analyst. Proven advanced knowledge and skills in data reporting, analytics and data management, utilising platforms or tools such as Microsoft Power Platform, SQL Database, Python (or equivalent) or ability to quickly acquire unfamiliar platforms. Proven ability to work collaboratively with diverse stakeholders to assess and respond to business requirements. Proven ability to map business processes, develop data management solutions and resolve complex data challenges. Proven critical thinking, project management, administrative and time management skills. A NDIS Workers Screening Card or be willing to obtain one. Why RFQ? Competitive remuneration packages. Enhance your take home pay with salary packaging of up to $15,900 on general living expenses and additionally up to $2,650 annual entertainment benefits, which also includes access to novated leasing. Explore your cost-of-living savings HERE! Free Employee Assistance Program (available for staff and their family). Opportunities for a wide range of career and professional development.

---

## Skills Comparison
### Technical Skills
- **CV Skills:** 12
- **JD Requirements:** 8
- **Matched:** 2
- **Match Rate:** 25.0%
- **Matched Skills:** Python, SQL
- **Missing Skills:** Dashboard Design, Data Analytics, Data Integrity, Data Management, Data Reporting, Microsoft Power Platform

### Soft Skills
- **CV Skills:** 7
- **JD Requirements:** 7
- **Matched:** 2
- **Match Rate:** 28.6%
- **Matched Skills:** Collaboration, Communication
- **Missing Skills:** Analytical Thinking, Critical Thinking, Leadership, Problem-solving, Time Management

### Domain Keywords
- **CV Keywords:** 8
- **JD Keywords:** 8
- **Matched:** 0
- **Match Rate:** 0.0%
- **Missing Keywords:** Business Requirements, Data Capability, Data Solutions, Not For Profit (NFP), Organisational Goals, Process Mapping, Project Management, Strategic Decision Making

## CV Skills Details
### Technical Skills (12):
Data Cleaning, Data Extraction, Data Preprocessing, Excel, Machine Learning, Matplotlib, Power BI, Predictive Analytics, Python, Seaborn, SQL, Tableau

### Soft Skills (7):
Analytical, Collaboration, Communication, Detail-oriented, Problem Solving, Results-driven, Teamwork

### Domain Keywords (8):
Business Processes, Client Satisfaction, Data Accuracy, Data-driven Decision-making, Not-for-profit Sectors, Operational Efficiency, Pipeline Efficiency, Strategic Decision-making

## Job Description Requirements
### Required Technical Skills (8):
Dashboard Design, Data Analytics, Data Integrity, Data Management, Data Reporting, Microsoft Power Platform, Python, SQL

### Required Soft Skills (7):
Analytical Thinking, Collaboration, Communication, Critical Thinking, Leadership, Problem-solving, Time Management

### Required Domain Keywords (8):
Business Requirements, Data Capability, Data Solutions, Not For Profit (NFP), Organisational Goals, Process Mapping, Project Management, Strategic Decision Making

## CV Information
- **CV Filename:** maheshwor_tiwari.pdf

## Analysis Details
- **Model Used:** unknown

---
*Generated from: /app/user/shiva@gmail.com/cv-analysis/applied_companies/Richmond_Fellowship_Queensland/Richmond_Fellowship_Queensland_skills_analysis_20251031_020149.json*