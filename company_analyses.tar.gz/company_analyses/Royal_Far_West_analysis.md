# Royal Far West - Skills Analysis Report

## Analysis Metadata
- **Analysis Date:** 2025-11-10 22:42:25
- **Source File:** `Royal_Far_West_skills_analysis_20251110_224225.json`
- **User:** kritik@gmail.com

## Job Description

Senior Data Analyst - Remote / Work from Home Royal Far West Job Summary Royal Far West Remote / Work from Home $100,000 - $109,999 per annum + salary packaging Applications close: Job posted on: 22nd Oct 2025 Sydney > Manly Part Time , Remote / Work from Home Information Technology & Digital Not For Profit (NFP) Job description The Senior Data Analyst will deliver high quality data analysis and reporting, including direction on data capture and management, the development of dashboards, reporting and data visualisation to support strategic decision-making and impact reporting. This role plays a critical part in in presenting RFW’s data to tell the story of the impact of our wellbeing services for children and families in rural and remote communities to our funders, community and supporters. Key responsibilities include data gathering, cleaning and preparation, data modelling, generating reports and visualizations, and communicating findings to stakeholders. This role will assist in driving efficient, sustainable and system-supported methods of data capture to continue to improve the access to and quality of our data and will independently seek out opportunities for continuous improvement. The position will partner with stakeholders across the organisation to identify gaps, recommend enhancements, and implement process to improve our capture of valuable data and present it in a meaningful way, in line with the RFW strategy. YOUR SKILLS AND EXPERIENCE ARE Tertiary qualifications in Business, Information Systems, or related discipline, or equivalent experience. Proven ability to engage stakeholders and build collaborative relationships. Experience with business process mapping tools, data analysis and a a variety of supporting systems, and system documentation. Experience with modern data warehousing solutions and data visualisation software solutions Experience with data governance processes Strong analytical and problem-solving skills, with the ability to identify and implement practical solutions. Strong written and verbal communication skills, with the ability to convey complex information clearly. Ability to manage multiple priorities, work independently, and deliver outcomes on time. Desirable Criteria Experience in the healthcare, education, disability, or not-for-profit sectors. Experience with Power BI. Experience with data cleansing or data improvement initiatives. Familiarity with compliance frameworks relevant to service delivery in health and community organisations. OUR CULTURE Royal Far West is a rewarding, inspiring, diverse and purpose driven workplace which aims to elevate and harness our people power to support the health and wellbeing of country children for generations to come. Our core values of Care, Connection, Passion, and Impact are integral to the organisation. Respecting and upholding these values enables us to maintain a positive, innovative and highly collaborative workplace culture. BENEFITS OFFERED Royal Far West has been recognised as one of Australia and New Zealand’s Best Places to Work in the prestigious annual list, published by The Australian Financial Review and Boss Magazine. Our extensive benefits offered, include: Structured induction program Meaningful work where you are making a positive difference. You will be supporting children’s mental health, their wellbeing and helping them to build resilience. Career and professional development opportunities : There are great opportunities to learn best practice, we offer an Impactful Leadership Program to emerging leaders, interactive workshops offered to develop your work skills as well as online mandatory training. Attractive remuneration : base salary pro rata of $110K pa + 12% superannuation Salary Packaging – up to $15,900 of your general living expenses can be offered tax free + meals and entertainment up to $2,650 pa tax free . Making this position worth the pro rata of $118,500 pa* See further details at www.gosalary.com.au Work/Life Balance – work from our beautiful location at Manly Beach or work from home. A laptop provided to work remotely and we offer a purchase leave scheme . Recognition & Reward – Length of service awards and recognition awards aligned to our values. Positive Culture – We are an inclusive organisation welcoming people from all walks of life! Beautiful location at Manly beach: easy access by bus, ferry and parking options. We are based in an architecturally designed building, purposely built to deliver our services. We have showers and towels available for your use so going for a swim before or after work is possible. CARE Days - up to 1 week off to look after individuals’ health and wellbeing, on top of Annual and Personal Leave, with the intention to provide employees with an opportunity to take regular breaks throughout the year. Benefits Program with discounts available on many high street purchases across Australia and access to novated car leasing. Pandemic Leave - 7 days paid leave, per calendar year to employees that have been impacted by either a disaster or pandemic which effects their ability to attend work. Gifted Leave - gifting leave of up to 3 working days over the Christmas and New year holiday period. Paid Parental Leave – 14 weeks full leave pay for the primary care giver and 4 weeks full leave for the non-primary care giver. Access to paid lactation breaks and lactation facilities. How to Apply If you like to take the first step in developing your career in a purpose led organisation, please submit your CV and cover letter, addressing the essential criteria, by clicking on the “

---

## Skills Comparison
### Technical Skills
- **CV Skills:** 15
- **JD Requirements:** 10
- **Matched:** 2
- **Match Rate:** 20.0%
- **Matched Skills:** Data Analysis, Power BI
- **Missing Skills:** Business Process Mapping, Dashboard Development, Data Cleansing, Data Governance, Data Modelling, Data Visualisation, Data Warehousing, Reporting

### Soft Skills
- **CV Skills:** 6
- **JD Requirements:** 6
- **Matched:** 2
- **Match Rate:** 33.3%
- **Matched Skills:** Communication, Time Management
- **Missing Skills:** Analytical Thinking, Collaboration, Problem-solving, Self-motivated

### Domain Keywords
- **CV Keywords:** 7
- **JD Keywords:** 7
- **Matched:** 0
- **Match Rate:** 0.0%
- **Missing Keywords:** Compliance Frameworks, Disability, Education, Healthcare, Impact Reporting, Not-for-Profit (NFP), Strategic Decision-Making

## CV Skills Details
### Technical Skills (15):
APIs, Business Intelligence, Computer Vision, Dart, Data Analysis, Data Visualization, Edge AI, Flutter, Multi-LLM, PostgreSQL, Power BI, Python, PyTorch, Report Generation, SQL

### Soft Skills (6):
Analytical, Communication, Motivated, Problem Solving, Teamwork, Time Management

### Domain Keywords (7):
AI Engineering, AI Model Evaluation, Automation, Corrosion Detection, Forecasting, Real-time Optimization, Training Prompts

## Job Description Requirements
### Required Technical Skills (10):
Business Process Mapping, Dashboard Development, Data Analysis, Data Cleansing, Data Governance, Data Modelling, Data Visualisation, Data Warehousing, Power BI, Reporting

### Required Soft Skills (6):
Analytical Thinking, Collaboration, Communication, Problem-solving, Self-motivated, Time Management

### Required Domain Keywords (7):
Compliance Frameworks, Disability, Education, Healthcare, Impact Reporting, Not-for-Profit (NFP), Strategic Decision-Making

## CV Information
- **CV Filename:** latest_cv.pdf

## Analysis Details
- **Model Used:** unknown

---
*Generated from: /app/user/kritik@gmail.com/cv-analysis/applied_companies/Royal_Far_West/Royal_Far_West_skills_analysis_20251110_224225.json*