# Foodbank - Skills Analysis Report

## Analysis Metadata
- **Analysis Date:** 2025-11-06 12:02:02
- **Source File:** `Foodbank_skills_analysis_20251106_120202.json`
- **User:** chunem@gmail.com

## Job Description

Data Analytics Officer - Foodbank - Remote / Work from Home Cause Recruitment Job Summary Cause Recruitment Remote / Work from Home Applications close: Job posted on: 12th Apr 2024 Sydney Contract , Full Time , Graduate , Part Time , Remote / Work from Home Information Technology & Digital Not For Profit (NFP) Job description Contract (with a view to go permanent) part time (3 or 4 days a week) or full-time role. Can be fully remote Australia wide or hybrid working arrangement from Sydney offices. Parking available onsite. Great entry-level role with competitive salary and salary packaging on offer. Outstanding opportunity to join this incredible national charity at an exciting time of growth. ORGANISATION Foodbank is the largest hunger relief charity in Australia, providing more than 70% of the food rescued for food relief nation-wide. As the pantry to the charity sector, they work with over 2,800 charities to get food and groceries to people who need a hand and are support more than 3000 School Breakfast Programs nationally. Foodbank sourced enough food for over 92 million meals last year alone. ROLE Rare opportunity ideal for someone looking to use their exceptional numeracy skills (with a background from Accounting, Commerce, Business or Data Analytics) or a recent graduate - to use data-led insights and research information to assist this incredible charity. Reporting to the General Manager of Information Technology, this national role will use Power BI and SQL and is responsible for collecting, organising, analysing and interpreting large datasets to provide insights and solutions, enhancing business processes and identifying trends. This is a fantastic opportunity to use your strong numeracy and problem-solving abilities, working productively for a highly respected national food relief charity in a team that is collaborative, values-based and passionate about making a real impact on the lives of thousands of Aussie families across the country. RESPONSIBILITIES Data Collection and Cleaning: Gather data from various sources, ensuring its accuracy, completeness, and reliability. Clean and preprocess data to prepare it for analysis. Data Analysis: Utilise statistical methods, data mining techniques, and analysis to extract meaningful insights from datasets. Identify trends, patterns, and correlations to inform business strategies. Reporting and Visualisation: Develop dashboards, reports, and visualisations to communicate findings effectively to stakeholders. Present insights in a clear and understandable manner to support decision-making processes. Continuous Learning and Development: Stay updated with the latest developments in data analytics, tools, and methodologies. Continuously improve analytical techniques and processes to enhance efficiency and effectiveness. YOUR SKILLS & ATTRIBUTES High degree of numeracy skills. Strong analytical thinking and problem-solving abilities. Ability to work independently to navigate best outcome from imperfect real-world data. High level of proficiency with Excel and other office products. Skills with Power BI and MSSQL will also be useful. Understanding of Data warehousing concepts and experience with data cleaning and transformation Excellent communication and presentation skills with ability to convey technical concepts to non-technical stakeholders in clear and concise manner. Strong interpersonal skill with ability to collaborate effectively in cross-functional teams. Meticulous attention to detail and a commitment to data accuracy and integrity. Proactive problem solving with ability to find innovative solutions. BENEFITS What’s in it for you? Competitive Salary package on offer including mobile phone allowance. A hybrid work model with flexible working hours and remote working options. Generous salary packaging as a not-for-profit organisation. Access to an Employment Assistance Program. Opportunities for professional development and training. Dynamic and collaborative work environment. If you are keen to use your experience in data-led insights, possess strong numeracy skills with strong attention to detail and strong communication skills, and bring initiative with an interest in making an impact, we want to hear from you! Click '

---

## Skills Comparison
### Technical Skills
- **CV Skills:** 6
- **JD Requirements:** 14
- **Matched:** 2
- **Match Rate:** 14.3%
- **Matched Skills:** Power BI, SQL
- **Missing Skills:** Data Analysis, Data Cleaning, Data Collection, Data Mining, Data Preprocessing, Data Transformation, Data Warehousing, Excel, MSSQL, Reporting, Statistical Methods, Visualisation

### Soft Skills
- **CV Skills:** 4
- **JD Requirements:** 11
- **Matched:** 2
- **Match Rate:** 18.2%
- **Matched Skills:** Analytical Thinking, Communication
- **Missing Skills:** Adaptability, Attention to Detail, Collaboration, Interpersonal Skills, Presentation Skills, Proactive, Problem-solving, Results-driven, Self-motivated

### Domain Keywords
- **CV Keywords:** 6
- **JD Keywords:** 12
- **Matched:** 0
- **Match Rate:** 0.0%
- **Missing Keywords:** Business Processes, Charity, Data Analytics, Data-led Insights, Decision-making, Food Relief, Hunger Relief, Insights, Not For Profit (NFP), School Breakfast Programs, Stakeholders, Trends

## CV Skills Details
### Technical Skills (6):
Matplotlib, Power BI, Python, Seaborn, SQL, Tableau

### Soft Skills (4):
Analytical Thinking, Communication, Problem Solving, Teamwork

### Domain Keywords (6):
Dashboard Creation, Data Analysis, Data Cleaning, Data Extraction, Machine Learning, Predictive Modeling

## Job Description Requirements
### Required Technical Skills (14):
Data Analysis, Data Cleaning, Data Collection, Data Mining, Data Preprocessing, Data Transformation, Data Warehousing, Excel, MSSQL, Power BI, Reporting, SQL, Statistical Methods, Visualisation

### Required Soft Skills (11):
Adaptability, Analytical Thinking, Attention to Detail, Collaboration, Communication, Interpersonal Skills, Presentation Skills, Proactive, Problem-solving, Results-driven, Self-motivated

### Required Domain Keywords (12):
Business Processes, Charity, Data Analytics, Data-led Insights, Decision-making, Food Relief, Hunger Relief, Insights, Not For Profit (NFP), School Breakfast Programs, Stakeholders, Trends

## CV Information
- **CV Filename:** maheshwor_tiwari.pdf

## Analysis Details
- **Model Used:** unknown

---
*Generated from: /app/user/chunem@gmail.com/cv-analysis/applied_companies/Foodbank/Foodbank_skills_analysis_20251106_120202.json*